package com.example.appet

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
